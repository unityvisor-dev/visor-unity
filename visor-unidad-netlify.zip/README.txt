VISOR — Unity (IA hospedada) • Netlify

Estructura:
- index.html → interfaz (frontend)
- netlify/functions/analyze.js → función serverless que llama al modelo LLM
- data/rules.json → constantes auxiliares (Regla Suprema, Pilares, frases base)

Cómo desplegar en Netlify (rápido):
1) Subí toda esta carpeta al panel de Netlify (drag & drop) o conectá un repo Git.
2) En Site configuration → Environment variables, creá:
   - OPENAI_API_KEY = tu_clave_de_API
3) Publicá. Probar en: https://tu-sitio.netlify.app
4) En la página, escribí un símbolo y presioná “Procesar con IA”.

Seguridad:
- La clave va en variables de entorno (no en el código).
- La función serverless corre del lado del servidor de Netlify.

Notas:
- Podés cambiar el modelo en analyze.js (propiedad "model").
- Si querés agregar más reglas o frases base, editá data/rules.json.
