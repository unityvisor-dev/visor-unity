// netlify/functions/analyze.js
export default async (req, context) => {
  try {
    const body = await req.json();
    const simbolo = (body?.simbolo || "").trim();
    const contexto = (body?.contexto || "").trim();

    if (!simbolo) {
      return new Response(JSON.stringify({ error: "Símbolo vacío" }), { status: 400 });
    }

    const prompt = `Sos el VISOR. Aplicás SIEMPRE:
- Regla Suprema: no-identificación, no-dualidad, no-juicio.
- Tres Pilares: UCDM, Kabbalah, Kybalion.
- Protocolo de salida SIEMPRE en JSON con el siguiente esquema EXACTO:

{
 "filtrado": {
   "regla_suprema": "No-identificación · No-dualidad · No-juicio",
   "pilares": ["UCDM","Kabbalah","Kybalion"],
   "resultado": "Símbolo filtrado por la Regla Suprema y los Tres Pilares: limpio (sin juicio, sin identificación, no-dual)."
 },
 "lectura": {
   "gancho": "palabra_corta_sobre_el_gancho_del_ego",
   "causa": "separacion_miedo|culpa|escasez|etc",
   "perdon": "presente_paz|inocencia|unidad|etc",
   "frases": ["frase vibracional 1","frase vibracional 2"]
 },
 "complementos": [
   {"nombre":"Hebreo-Fibonacci","motivo":"por qué fue útil","ranking":0.9}
 ],
 "resumen_final": "2-3 líneas con la devolución central no-dual."
}

Entrada del usuario:
- Símbolo: ${simbolo}
- Contexto: ${contexto}`;

    // Llamado al proveedor de IA (OpenAI como ejemplo)
    const resp = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        temperature: 0.2,
        response_format: { type: "json_object" }
      })
    });

    if (!resp.ok) {
      const txt = await resp.text();
      return new Response(JSON.stringify({ error: "Falla al llamar a la IA", detalle: txt }), { status: 500 });
    }

    const out = await resp.json();
    let content = out?.choices?.[0]?.message?.content || "{}";
    let data;
    try { data = JSON.parse(content); }
    catch {
      data = { error: "Respuesta no parseable", raw: content };
    }

    // fallback mínimo si la IA no devuelve complementos
    if (!data.complementos) data.complementos = [];
    if (!Array.isArray(data.complementos)) data.complementos = [data.complementos].filter(Boolean);

    return new Response(JSON.stringify(data), { status: 200, headers: { "Content-Type": "application/json" }});
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500 });
  }
};
